# Un programme qui trace une courbe
